# Sophia AI — Android starter

This is a first runnable Android Studio project scaffold for the user's private Bengali AI assistant.

## Included in this starter
- Kotlin + Jetpack Compose interface
- Bengali speech recognition via Android's installed speech recognition service
- Bengali text-to-speech where the device has a Bengali voice installed
- Basic offline intents: open YouTube, Facebook, and the alarm screen
- Microphone permission requested at runtime

## Not yet included
- A connected online LLM. Add a secure backend and keep API keys on the server, never in the APK.
- Persistent conversation memory, user accounts, screen understanding, and broader device automation.
- Automated posting, sending messages, or other sensitive actions. These need supported APIs and explicit user confirmation.
- An offline language model. Offline commands here are a small fixed set, not a full offline AI.

## Build
1. Install Android Studio (recent stable version) and Android SDK 35.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test on your own Android phone. Grant microphone permission when asked.

The project targets Android 8.0+ (minSdk 26). For a public release, review privacy, permissions, Play policy, signing, and security.
