package com.sophiaai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speakReady = false
    private var onRecognized: ((String) -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startSpeechRecognition()
            else onRecognized?.invoke("মাইক্রোফোন ব্যবহারের অনুমতি দেওয়া হয়নি।")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            SophiaScreen(
                onListen = { callback ->
                    onRecognized = callback
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) startSpeechRecognition()
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSpeak = { speak(it) },
                onCommand = { command -> handleOfflineCommand(command) }
            )
        }
    }

    override fun onInit(status: Int) {
        speakReady = status == TextToSpeech.SUCCESS
        if (speakReady) tts?.language = Locale("bn", "IN")
    }

    private fun speak(text: String) {
        if (speakReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sophia_reply")
    }

    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sophia-কে কিছু বলুন")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            onRecognized?.invoke("এই ফোনে speech recognition চালু করা যায়নি।")
        }
    }

    @Deprecated("Deprecated by Android; retained here for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            onRecognized?.invoke(spoken.ifBlank { "কথা বুঝতে পারিনি, আবার বলুন।" })
        }
    }

    private fun handleOfflineCommand(raw: String): String {
        val q = raw.lowercase(Locale.ROOT)
        val result = when {
            "youtube" in q || "ইউটিউব" in q -> {
                launchPackage("com.google.android.youtube")
                "YouTube খোলার চেষ্টা করছি।"
            }
            "facebook" in q || "ফেসবুক" in q -> {
                launchPackage("com.facebook.katana")
                "Facebook খোলার চেষ্টা করছি।"
            }
            "ঘড়ি" in q || "অ্যালার্ম" in q || "alarm" in q -> {
                val i = Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)
                if (i.resolveActivity(packageManager) != null) startActivity(i)
                "অ্যালার্ম অ্যাপ খুলছি।"
            }
            else -> "এই কাজটির জন্য অনলাইন AI সংযোগ দরকার। আপাতত YouTube, Facebook ও অ্যালার্ম খোলার কমান্ড চালু আছে।"
        }
        return result
    }

    private fun launchPackage(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) startActivity(intent)
        else startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(
            if (packageName.contains("youtube")) "https://www.youtube.com" else "https://www.facebook.com"
        )))
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun SophiaScreen(
    onListen: ((String) -> Unit) -> Unit,
    onSpeak: (String) -> Unit,
    onCommand: (String) -> String
) {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Sophia: হ্যালো! আমি Sophia। কীভাবে সাহায্য করতে পারি?")) }
    val bg = Brush.verticalGradient(listOf(Color(0xFF10152F), Color(0xFF281747), Color(0xFF080B18)))
    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(bg).padding(20.dp)) {
            Text("SOPHIA AI", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Text("তোমার ব্যক্তিগত AI সহকারী", color = Color(0xFFCBC8E8))
            Spacer(Modifier.height(22.dp))
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(132.dp).background(
                        Brush.radialGradient(listOf(Color(0xFFB58CFF), Color(0xFF5737A8))),
                        CircleShape), contentAlignment = Alignment.Center) {
                        Text("S", color = Color.White, style = MaterialTheme.typography.displayLarge)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("আমি শুনছি…", color = Color.White)
                }
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 210.dp)) {
                items(messages) { line ->
                    Text(line, color = Color.White, modifier = Modifier.fillMaxWidth()
                        .padding(vertical = 5.dp).background(Color(0x332B2E55), RoundedCornerShape(12.dp)).padding(12.dp))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Sophia-কে লিখুন…") },
                    singleLine = true)
                IconButton(onClick = {
                    onListen { heard ->
                        messages = messages + "তুমি: $heard"
                        val reply = onCommand(heard)
                        messages = messages + "Sophia: $reply"
                        onSpeak(reply)
                    }
                }) { Icon(Icons.Default.Mic, contentDescription = "ভয়েস", tint = Color.White) }
                IconButton(onClick = {
                    if (input.isNotBlank()) {
                        val sent = input
                        messages = messages + "তুমি: $sent"
                        val reply = onCommand(sent)
                        messages = messages + "Sophia: $reply"
                        onSpeak(reply)
                        input = ""
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "পাঠান", tint = Color.White) }
            }
            Text("প্রাথমিক সংস্করণ • অনলাইন AI সংযোগ এখনো যুক্ত করা হয়নি",
                color = Color(0xFFB9B5D0), style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}
